package it.unifi.swe.cepms.server_module.main;

import it.unifi.swe.cepms.server_module.business_logic.EndpointPageController;

public class Main {
    public static void main(String[] args) {
//        AuthProxy ap = new AuthProxy();
//        EndpointPageController ep = new EndpointPageController();
//        String OTK = ep.generateOTK();
//        System.out.println(ep.generateOTK());
//        ep.associateEndpoint(OTK, 1, "office_1");
    }
}
