package it.unifi.swe.cepms;

public enum ScanType {
    FullScan,
    FastScan
}
